
int main()
{
    int x, ara[3];
    ara[0] = 5;
    x = 2;
    println(ara[0]*2 + x-1);
    println(x);
    println(ara[0]);
    println(5>6 || ara[0] == 5);
    x = 3;
    println(x > 3);
    return 0;

}